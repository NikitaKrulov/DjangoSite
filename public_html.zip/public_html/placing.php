<?php













ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Проверка капчи
$recaptchaSecretKey = '6LfwfAkpAAAAAD6iOEBIuhvQ0yyW78FIgpTadjQ2';
$recaptchaResponse = $_POST['g-recaptcha-response'];

$recaptchaUrl = 'https://www.google.com/recaptcha/api/siteverify';
$recaptchaData = [
    'secret' => $recaptchaSecretKey,
    'response' => $recaptchaResponse
];

$options = [
    'http' => [
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($recaptchaData)
    ]
];

$context = stream_context_create($options);
$recaptchaResult = json_decode(file_get_contents($recaptchaUrl, false, $context), true);

if ($recaptchaResult['success'] === true) {
// Подключение к базе данных (замените данными для вашей БД)
$host = 'localhost';
$dbname = 'nekitkrulo';
$username = 'nekitkrulo';
$password = 'FCWi5YN&1LHUW853';

// Создаем соединение
$conn = new mysqli($host, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Ошибка соединения с базой данных: " . $conn->connect_error);
}

// Получение данных из формы
$name = $_POST['name'];
$surname = $_POST['lastname'];
$email = $_POST['email'];
$price = $_POST['price2']; 
$adress = $_POST['adress']; 

// Добавляем данные в таблицу completed_orders
$sql = "INSERT INTO completed_orders (name, surname, email, price, address) VALUES ('$name', '$surname', '$email', '$price', '$adress')";

if ($conn->query($sql) === TRUE) {
    echo "Данные успешно добавлены в базу данных.";

    // Теперь, после успешной вставки данных, очищаем таблицу DataToCart
    $deleteDataToCartSql = "DELETE FROM DataToCart";
    
    if ($conn->query($deleteDataToCartSql) === TRUE) {
        echo "Таблица DataToCart очищена.";
    } else {
        echo "Ошибка при очистке таблицы DataToCart: " . $conn->error;
    }
} else {
    echo "Ошибка при добавлении данных в базу данных: " . $conn->error;
}

// Закрываем соединение с базой данных
$conn->close();
header('Location: ordered.php'); // перенаправление
exit;

// Закрываем соединение с базой данных
$conn->close();

} else {
    echo '<div class="error-message"><h1>Ошибка: Пожалуйста, пройдите проверку reCAPTCHA.</h1><br><a href="./cart.html">Вернуться в корзину</a></div>';
    echo '<style>';
    echo '.error-message { 
        color: #55ffe3;
        font-weight: bold;
        font-size: 40px;
        margin: auto;
        display: flex;
        height: 100%;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        background-color: #555555;
        border-radius: 30px;
     }';
    echo '.error-message a{ 
        color: #fff;
        font-weight: bold;
        font-size: 40px;
     }';
    echo '</style>';
    exit; 
}

?>

