<?php
/*
Template Name: contactsphp
*/
?>
 
 <!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../wp-content/themes/twentytwentyfour/styles/style_conatcts.css">
    <link rel="shortcut icon" href="../wp-content/themes/twentytwentyfour/assets/images/logo.png" type="image/png">
    <title>EcoLife</title>
</head>
<nav>
        <div class="nav_container">
            <div class="logo">
                <a href="http://nekitkrulo.temp.swtest.ru/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f/"><img src="../wp-content/themes/twentytwentyfour/assets/images/logo.png" alt="logo"></a>
            </div>
            <div class="nav_links">
                <a href="http://nekitkrulo.temp.swtest.ru/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f/#about_us">О нас</a>
                <a href="http://nekitkrulo.temp.swtest.ru/contacts/">Контакты</a>
                <a href="http://nekitkrulo.temp.swtest.ru/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f/#product">Продукция</a>
            </div>
            <div class="cart_container">
                <a href="http://nekitkrulo.temp.swtest.ru/cart/">Корзина</a>
            </div>
        </div>
        <div class="burger">
            <button id="burger_btn"><img src="../wp-content/themes/twentytwentyfour/assets/images/burger-bar.png" alt="burger-bar"></button>
            <div class="burger_menu">
                <div class="burger_logo">
                    <a href="http://nekitkrulo.temp.swtest.ru/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f/"><img src="../wp-content/themes/twentytwentyfour/assets/images/logo.png" alt="logo"></a>
                </div>
                <div class="burger_nav_links">
                    <a href="http://nekitkrulo.temp.swtest.ru/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f/#about_us">О нас</a>
                    <a href="http://nekitkrulo.temp.swtest.ru/contacts/">Контакты</a>
                    <a href=".http://nekitkrulo.temp.swtest.ru/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f/#product">Продукция</a>
                </div>
                <div class="burger_cart_container">
                    <a href="http://nekitkrulo.temp.swtest.ru/cart/">Корзина</a>
                </div>
            </div>
        </div>
    </nav>
<!-- КОНТЕНТ СТРАНИЦЫ -->     
  
<main>
        <div class="main_content">
            <div class="information">
                <form action="" method="post">
                    <div class="group_info">
                        <label for="name">Имя:</label>
                        <input type="text" name="name" id="name" autocomplete="name">
                    </div>
                    <div class="group_info">
                        <label for="email">E-mail:</label>
                        <input type="email" name="email" id="email" autocomplete="email">
                    </div>
                    <input type="submit" value="Отправить" class="btn_submit">
                </form>
                <?php
$host = 'localhost';
$dbname = 'nekitkrulo';
$username = 'nekitkrulo';
$password = 'FCWi5YN&1LHUW853';

$conn = new mysqli($host, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Ошибка соединения с базой данных: " . $conn->connect_error);
}

// Получение данных из формы
$name = $_POST['name'];
$email = $_POST['email'];

// Добавляем данные в таблицу completed_orders
$sql = "INSERT INTO Contacts (name, email) VALUES ('$name', '$email')";

if ($conn->query($sql) === TRUE) {
    echo "Данные успешно добавлены в базу данных.";

} else {
    echo "Ошибка при добавлении данных в базу данных: " . $conn->error;
}

// Закрываем соединение с базой данных
$conn->close();
header('http://nekitkrulo.temp.swtest.ru/contacts/'); // перенаправление
exit;
?>
                <div class="adress">
                    <p><span>Адрес: </span>Тверская улица, 9, Москва, 125009</p>
                    <a href="#foot">Посмотреть на карте<img src=".../wp-content/themes/twentytwentyfour/assets/images/fast-forward-1--unscreen.gif" alt="arrow"></a>
                </div>
            </div>
            <div class="map_conatainer">
                <iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3Ab19f6e202f50f39e344fa1a337a3d54897f9075db145ee30e6777d03a844534f&amp;source=constructor"  frameborder="0"></iframe>
            </div>
        </div>
    </main>




<?php get_footer(); ?>