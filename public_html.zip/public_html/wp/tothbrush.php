<?php
/*
Template Name: toothbrush
*/
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta name="google-site-verification" content="LIMWkNrbU4oK53luYm17kaRlOhiAkTEJXX00q9NFPxs" />
    <meta name="yandex-verification" content="a415a232389bbc19" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../wp-content/themes/twentytwentyfour/styles/productDetail.css">
    <link rel="shortcut icon" href="../wp-content/themes/twentytwentyfour/assets/images/logo.png" type="image/png">
    <title>EcoLife</title>
</head>

<body>
    <nav>
        <div class="nav_container">
            <div class="logo">
                <a href="http://nekitkrulo.temp.swtest.ru/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f/"><img src="../wp-content/themes/twentytwentyfour/assets/images/logo.png" alt="logo"></a>
            </div>
            <div class="nav_links">
                <a href="http://nekitkrulo.temp.swtest.ru/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f/#about_us">О нас</a>
                <a href="http://nekitkrulo.temp.swtest.ru/contacts/">Контакты</a>
                <a href="http://nekitkrulo.temp.swtest.ru/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f/#product">Продукция</a>
            </div>
            <div class="cart_container">
                <a href="http://nekitkrulo.temp.swtest.ru/cart/">Корзина</a>
            </div>
        </div>
        <div class="burger">
            <button id="burger_btn"><img src="../wp-content/themes/twentytwentyfour/assets/images/burger-bar.png" alt="burger-bar"></button>
            <div class="burger_menu">
                <div class="burger_logo">
                    <a href="http://nekitkrulo.temp.swtest.ru/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f/"><img src="../wp-content/themes/twentytwentyfour/assets/images/logo.png" alt="logo"></a>
                </div>
                <div class="burger_nav_links">
                    <a href="http://nekitkrulo.temp.swtest.ru/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f/#about_us">О нас</a>
                    <a href="http://nekitkrulo.temp.swtest.ru/contacts/">Контакты</a>
                    <a href=".http://nekitkrulo.temp.swtest.ru/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f/#product">Продукция</a>
                </div>
                <div class="burger_cart_container">
                    <a href="http://nekitkrulo.temp.swtest.ru/cart/">Корзина</a>
                </div>
            </div>
        </div>
    </nav>
<main>
<section id="productDetail" class="productDetail">
            <div class="container text-center">
                <div class="productDetail__name">
                    <h2 id="nameProduct">Зубная щетка из Бамбука</h2>
                    <div class="productDetail__name-bottom">
                        <div class="productDetail__name-stars">
                            <span class="material-symbols-outlined">star</span>
                            <span class="material-symbols-outlined">star</span>
                            <span class="material-symbols-outlined">star</span>
                            <span class="material-symbols-outlined material-symbols-outlined-none">star</span>
                            <span class="material-symbols-outlined material-symbols-outlined-none">star</span>
                            <a href="">2
                                отзыва</a>
                        </div>

                        <a href="" class="productDetail__name-share"><span
                                class="material-symbols-outlined material-symbols-outlined-share">share</span>поделится</a>
                    </div>
                </div>
                <div class="row row__productDetail">
                    <div class="col col__productDetail col__productDetail-swiper">
                        <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff"
                            class="swiper mySwiper2">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <img src="../wp-content/themes/twentytwentyfour/assets/images/ECO Tothbrush.jpeg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-2.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-3.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-4.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-5.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-6.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-7.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-8.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-9.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-10.jpg" />
                                </div>
                            </div>
                            <div class="swiper-button-next swiper__btn"></div>
                            <div class="swiper-button-prev swiper__btn"></div>
                        </div>
                        <div thumbsSlider="" class="swiper mySwiper">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <img src="../wp-content/themes/twentytwentyfour/assets/images/ECO FOOD.jpeg" id="firstImgProduct"/>
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-2.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-3.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-4.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-5.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-6.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-7.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-8.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-9.jpg" />
                                </div>
                                <div class="swiper-slide">
                                    <img src="https://swiperjs.com/demos/images/nature-10.jpg" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col col__productDetail col__productDetail-discription">
                        <ul>
                            <li><span>Тип:</span> 1</li>
                            <li><span>Бренд:</span> 1</li>
                            <li><span>оличество в упаковке, шт:</span>1</li>
                            <li><span>Пищевая ценность продукта:</span>1</li>
                            <li><span>Срок годности в днях:</span>1</li>
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laudantium blanditiis
                                voluptatem quam omnis iste, ab odio vel asperiores officiis nam facilis beatae nesciunt
                                autem ipsum expedita modi laborum. Deleniti, veritatis.
                                Aliquid accusamus aperiam error, totam eum a accusantium quas laudantium sapiente
                                dignissimos quia incidunt voluptate, explicabo quidem qui? Asperiores aut maiores
                                incidunt ad minus libero alias voluptatum quasi accusamus dolores?
                                Laborum iusto obcaecati reprehenderit magnam eius necessitatibus repellendus corporis
                                quas incidunt, molestiae voluptate quam nisi accusamus. </p>
                        </ul>
                    </div>
                    <div class="col col__productDetail col__productDetail-price">
                        <div class="col__productDetail-sale">
                            <div class="col__productDetail-saleImg">
                                <img src="../wp-content/themes/twentytwentyfour/assets/images/336_lastDay_bigPromo_logo_eecf5628-a142-41f1-9987-0942b81de9ec.webp"
                                    alt="">
                                <p>Распродажа</p>
                            </div>
                            <div class="col__productDetail-days">
                                <p>4 дня</p>
                                <p>осталось</p>
                            </div>

                        </div>
                        <div class="card">
                            <p class="card__price" id="price"><span>Цена</span>3000</p>
                            <p class="card__price-old">7000</p>
                            <div class="card__delivery">
                                <div class="card__delivery-info">
                                    <p>Курьером EcoLife Fresh</p>
                                    <p>Сегодня, 2 марта</p>
                                </div>
                                <div class="card__delivery-price">
                                    <p>99 ₽</p>
                                </div>
                            </div>
                            <a href="" class="card__btn" id="toothbrash"><span>В корзину</span></a>
                        </div>
                    </div>

                </div>
                <p class="text-start mt-3 mb-5">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Odit quaerat
                    reiciendis nam facilis fugit dolorem repellat, totam alias qui recusandae optio error quos eligendi
                    cum dolor modi porro, ex id.
                    Labore quo harum illo doloremque debitis fugit ratione eius sunt, voluptatibus ipsa eos doloribus
                    aperiam sapiente dicta! Explicabo sequi eveniet expedita modi deserunt deleniti velit rerum sit.
                    Reprehenderit, laboriosam debitis.
                    Minima a beatae vero sed delectus laudantium dolores velit repellat nostrum facilis! Dicta assumenda
                    distinctio totam mollitia, praesentium ullam perferendis voluptatem est quasi delectus reiciendis
                    incidunt sed. Provident, sint nisi.
                    Corrupti quasi distinctio possimus voluptatibus delectus perferendis et? Doloremque sequi ipsam ex
                    non vel reiciendis voluptatibus repudiandae rem accusamus officia saepe totam consequuntur, sed quis
                    rerum quisquam tempore tempora quasi.
                    Nisi labore ea nobis dolores optio quibusdam soluta in fugit odit voluptatem, cupiditate quidem.
                    Iusto odit vero voluptas voluptates illo assumenda. Dolorem, voluptate architecto iste nisi
                    doloremque laudantium enim. Fugit. Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque
                    explicabo vero, aliquid consectetur, ratione ad quia dolor nemo tempore, reiciendis rerum ipsa
                    facere modi dolorem eum laboriosam quae? Itaque, eveniet!</p>

            </div>
        </section>
        <section class="reviews">
            <div class="container mt-5 mb-5">
                <h2>Отзывы</h2>
                <div class="productDetail__name-stars reviews__stars">
                    <span class="material-symbols-outlined">star</span>
                    <span class="material-symbols-outlined">star</span>
                    <span class="material-symbols-outlined">star</span>
                    <span class="material-symbols-outlined material-symbols-outlined-none">star</span>
                    <span class="material-symbols-outlined material-symbols-outlined-none">star</span>
                    <div class="reviews__text">
                        <p>3/5</p>
                    </div>
                </div>
                <div class="row g-2 swiper swiperReviews">
                    <div class="swiper-wrapper">
                        <div class="col-md-4 swiper-slide">
                            <div class="card p-3 text-center px-4">

                                <div class="user-image">

                                    <img src="../wp-content/themes/twentytwentyfour/assets/images/man1.jpg" class="rounded-circle" width="80">

                                </div>

                                <div class="user-content">

                                    <h5 class="mb-0">Bruce Hardy</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                        nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    </p>

                                </div>

                                <div class="ratings">
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined material-symbols-outlined-none">star</span>
                                    <span class="material-symbols-outlined material-symbols-outlined-none">star</span>
                                    <span class="material-symbols-outlined material-symbols-outlined-none">star</span>

                                </div>

                            </div>
                        </div>

                        <div class="col-md-4 swiper-slide">

                            <div class="card p-3 text-center px-4">

                                <div class="user-image">

                                    <img src="../wp-content/themes/twentytwentyfour/assets/images/man2.jpg" class="rounded-circle" width="80">

                                </div>

                                <div class="user-content">

                                    <h5 class="mb-0">Mark Smith</h5>

                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                        nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    </p>

                                </div>

                                <div class="ratings">
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined material-symbols-outlined-none">star</span>

                                </div>

                            </div>

                        </div>

                        <div class="col-md-4 swiper-slide">

                            <div class="card p-3 text-center px-4">

                                <div class="user-image">

                                    <img src="../wp-content/themes/twentytwentyfour/assets/images/man3.jpg" class="rounded-circle" width="80">

                                </div>

                                <div class="user-content">

                                    <h5 class="mb-0">Veera Duncan</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                        nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    </p>

                                </div>

                                <div class="ratings">
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>
                                </div>

                            </div>

                        </div>

                        <div class="col-md-4 swiper-slide">
                            <div class="card p-3 text-center px-4">

                                <div class="user-image">

                                    <img src="../wp-content/themes/twentytwentyfour/assets/images/man1.jpg" class="rounded-circle" width="80">

                                </div>

                                <div class="user-content">

                                    <h5 class="mb-0">Bruce Hardy</h5>

                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                        nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    </p>

                                </div>

                                <div class="ratings">
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined ">star</span>
                                    <span class="material-symbols-outlined material-symbols-outlined-none">star</span>
                                    <span class="material-symbols-outlined material-symbols-outlined-none">star</span>

                                </div>

                            </div>
                        </div>

                        <div class="col-md-4 swiper-slide">

                            <div class="card p-3 text-center px-4">

                                <div class="user-image">

                                    <img src="../wp-content/themes/twentytwentyfour/assets/images/man2.jpg" class="rounded-circle" width="80">

                                </div>

                                <div class="user-content">

                                    <h5 class="mb-0">Mark Smith</h5>

                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                        nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    </p>

                                </div>

                                <div class="ratings">
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined material-symbols-outlined-none">star</span>
                                    <span class="material-symbols-outlined material-symbols-outlined-none">star</span>
                                    <span class="material-symbols-outlined material-symbols-outlined-none">star</span>
                                    <span class="material-symbols-outlined material-symbols-outlined-none">star</span>

                                </div>

                            </div>

                        </div>

                        <div class="col-md-4 swiper-slide">

                            <div class="card p-3 text-center px-4">

                                <div class="user-image">

                                    <img src="../wp-content/themes/twentytwentyfour/assets/images/man3.jpg" class="rounded-circle" width="80">

                                </div>

                                <div class="user-content">

                                    <h5 class="mb-0">Veera Duncan</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                        nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    </p>

                                </div>

                                <div class="ratings">
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>
                                    <span class="material-symbols-outlined">star</span>

                                </div>

                            </div>

                        </div>

                    </div>


                </div>

            </div>
        </section>

        <section class="seeAlso">
            <div class="container">
                <h2>Смотрите также</h2>
                <div class="row d-flex justify-content-between ">
                    <a href=".http://nekitkrulo.temp.swtest.ru/bamboo/" class="col seeAlso__col text-center">
                        <img src="../wp-content/themes/twentytwentyfour/assets/images/f8f3b7c421138e393766f863d8f19127.png" alt="">
                        <p class="seeAlso__col-name">Эко-посуда из бамбука</p>
                        <p class="seeAlso__col-price"><span>Цена:</span> 5000</p>
                        <div class="seeAlso__col-hover">
                            <p>Подробнее</p>
                        </div>
                    </a>
                    <a href="http://nekitkrulo.temp.swtest.ru/banka/" class="col seeAlso__col text-center">
                        <img src="../wp-content/themes/twentytwentyfour/assets/images/ECO FOOD.jpeg" alt="">
                        <p class="seeAlso__col-name">Банка полезной еды</p>
                        <p class="seeAlso__col-price"><span>Цена:</span> 1000</p>
                        <div class="seeAlso__col-hover">
                            <p>Подробнее</p>
                        </div>
                    </a>
                    <a href="http://nekitkrulo.temp.swtest.ru/tea/" class="col seeAlso__col text-center">
                        <img src="../wp-content/themes/twentytwentyfour/assets/images/ECO Tea.jpeg" alt="">
                        <p class="seeAlso__col-name"> Эко-набор для чая</p>
                        <p class="seeAlso__col-price"><span>Цена:</span> 10000</p>
                        <div class="seeAlso__col-hover">
                            <p>Подробнее</p>
                        </div>
                    </a>
                </div>
            </div>

        </section>
    </main>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js"
        integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script>
        var swiper = new Swiper(".mySwiper", {
            loop: true,
            spaceBetween: 10,
            slidesPerView: 4,
            freeMode: true,
            watchSlidesProgress: true,
        });
        var swiper2 = new Swiper(".mySwiper2", {
            loop: true,
            spaceBetween: 10,
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
            thumbs: {
                swiper: swiper,
            },
        });
        var swiper3 = new Swiper(".swiperReviews", {
            loop: true,
            spaceBetween: 10,
            slidesPerView: 3.3,
            breakpoints: {
            998: {
                spaceBetween: 10,
                slidesPerView: 3.3,
            },
            769: {
                spaceBetween: 10,
                slidesPerView: 2.2,
            },
            0: {
                spaceBetween: 10,
                slidesPerView: 1.2,
            },
        }
        });
    </script>
    <!-- Подключение библиотеки jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>


<script>
$(document).ready(function(){
    let buttonClicked = false;

    $("#toothbrash").click(function(event){
        event.preventDefault();

        if (buttonClicked) {
            console.log('Кнопка уже была нажата!');
            return;
        }

        var name = $("#nameProduct").text();
        var image = $("#firstImgProduct").attr("src");
        var price = $("#price").contents().filter(function() {
            return this.nodeType === 3;
        }).text().trim();

        // Добавление атрибута disabled и изменение текста кнопки
        $(this).attr('disabled', true).find('span').text('Добавлено!');

        buttonClicked = true;

        $.ajax({
            type: "POST", 
            url: "getData.php", // Используйте правильный путь к обработчику
            data: {
                name: name,
                image: image,
                price: price
            },
            success: function(response){
                console.log(response);

                var responseData = JSON.parse(response);

                if (responseData.message === 'Товар успешно добавлен в корзину!') {
                    // Отложенное обновление текста и возврат кнопки к исходному состоянию через 2 секунды
                    setTimeout(function() {
                        $("#toothbrash").removeAttr('disabled').find('span').text('В корзину');
                        buttonClicked = false; // Сброс флага после возврата кнопки к исходному состоянию
                    }, 2000);
                } else if (responseData.message === 'Товар уже в корзине!') {
                    console.log('Товар уже в корзине!');
                } else {
                    console.error('Ошибка на сервере: ' + responseData.message);
                }
            },
            error: function(error){
                console.log(error);
            }
        });
    });
});



</script>
<?php get_footer(); ?>