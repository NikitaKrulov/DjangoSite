<?php
$host = 'localhost';
$dbname = 'nekitkrulo';
$username = 'nekitkrulo';
$password = 'FCWi5YN&1LHUW853';

$mysqli = new mysqli($host, $username, $password, $dbname);


if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST["name"];
    $price = $_POST["price"];
    $img_url = $_POST["img_url"];



    // SQL-запрос для вставки данных в таблицу DataToCart
    $sql = "INSERT INTO DataToCart (name, price, image) VALUES ('$name', $price, '$img_url')";

    if ($mysqli->query($sql) === true) {
        echo "success";
    } else {
        echo "error: " . $mysqli->error;
    }

    // закрытие конекта с БД
    $mysqli->close();
} else {
    echo "Invalid request method";
}
header('Location: index.html#product');// перенваправление
exit; 
?>