<?php
$host = 'localhost';
$dbname = 'nekitkrulo';
$username = 'nekitkrulo';
$password = 'FCWi5YN&1LHUW853';

$mysqli = new mysqli($host, $username, $password, $dbname);

if ($mysqli->connect_error) {
    die("Ошибка подключения к базе данных: " . $mysqli->connect_error);
}

// Выборка данных из таблицы DataToCart
$sql = "SELECT * FROM DataToCart";
$result = $mysqli->query($sql);

if ($result) {
    $data = array();

    // Преобразование результата запроса в ассоциативный массив
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    // Отправка данных в формате JSON
    echo json_encode($data);
} else {
    echo json_encode(array('message' => 'empty')); // Если корзина пуста
}

// Закрытие соединения с базой данных
$mysqli->close();
?>
