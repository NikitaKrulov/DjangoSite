<?php

// Подключение к базе данных (замените данными для вашей БД)
$host = 'localhost';
$dbname = 'nekitkrulo';
$username = 'nekitkrulo';
$password = 'FCWi5YN&1LHUW853';

// Создаем соединение
$conn = new mysqli($host, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Ошибка соединения с базой данных: " . $conn->connect_error);
}

// Выборка данных из базы данных
$sql = "SELECT address, price, email FROM completed_orders ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $address = $row['address'];
    $price = $row['price'];
    $email = $row['email'];
    $Ordrer = "Заказ оформлен!";
} else {
    // Если данных нет
    $address = "Адрес не указан";
    $price = "Цена не указана";
    $email = "Email не указан";
    $Ordrer = "Заказ не оформлен";
}
$conn->close();
?>
<?php
if (isset($_POST['clear_database'])) {
    $host = 'localhost';
    $dbname = 'nekitkrulo';
    $username = 'nekitkrulo';
    $password = 'FCWi5YN&1LHUW853';
    $conn = new mysqli($host, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Ошибка соединения с базой данных: " . $conn->connect_error);
    }

// Очистка данных в таблице completed_orders
$sql = "TRUNCATE TABLE completed_orders";

// Выполняем запрос на очистку таблицы
if ($conn->query($sql) === TRUE) {
    echo "База данных успешно очищена.";
} else {
    echo "Ошибка при очистке базы данных: " . $conn->error;
}

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles/style_ordered.css">
    <link rel="shortcut icon" href="./media/logo.png" type="image/png">
    <title>Заказ оформлен!</title>
</head>
<body>
   <nav>
        <div class="nav_container">
            <div class="logo">
                <a href="./index.html"><img src="./media/logo.png" alt="logo"></a>
            </div>
        </div>
    </nav>
    <main>
        <div class="content">
            <h1><?php echo $Ordrer; ?></h1>
            <div class="notif_container">
                <div class="notif_text">
                    <p class="adress"><?php echo $address; ?></p>
                    <p class="price"><?php echo $price; ?></p>
                    <p class="email"><?php echo $email; ?></p>
                </div>
            </div>
        </div>        
    </main>
    <footer>
        <div class="footer_all">
            <p>Официальный магазин EcoLife © 2024</p>
            <a href="./textolite/ordered.php" class="admin">Перейти в админку для этой страницы</a>
            <form method="post" action="ordered.php">
                <button type="submit" name="clear_database">Очистить БД</button>
            </form>
        </div>
    </footer>
    <script src="/test.js"></script>
</body>
</html>