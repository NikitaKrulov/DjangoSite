<?php
$host = 'localhost';
$dbname = 'nekitkrulo';
$username = 'nekitkrulo';
$password = 'FCWi5YN&1LHUW853';

$mysqli = new mysqli($host, $username, $password, $dbname);

if ($mysqli->connect_error) {
    die("Ошибка подключения к базе данных: " . $mysqli->connect_error);
}

// Принимаем параметры (массив item_ids) из клиентской части
$data = json_decode(file_get_contents("php://input"), true);
$itemIds = $data['item_ids'];

// Выполняем SQL-запрос для удаления записей из БД
foreach ($itemIds as $itemId) {
    $sql = "DELETE FROM DataToCart WHERE ID = " . $itemId;
    $result = $mysqli->query($sql);
}

if ($result) {
    echo json_encode(array("message" => "success"));
} else {
    echo json_encode(array("message" => "error"));
}

$mysqli->close();

?>