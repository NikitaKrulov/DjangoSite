<?php
$host = 'localhost';
$dbname = 'nekitkrulo';
$username = 'nekitkrulo';
$password = 'FCWi5YN&1LHUW853';

$conn = new mysqli($host, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Ошибка соединения с базой данных: " . $conn->connect_error);
}

// Получение данных из формы
$name = $_POST['name'];
$email = $_POST['email'];

// Добавляем данные в таблицу completed_orders
$sql = "INSERT INTO Contacts (name, email) VALUES ('$name', '$email')";

if ($conn->query($sql) === TRUE) {
    echo "Данные успешно добавлены в базу данных.";

} else {
    echo "Ошибка при добавлении данных в базу данных: " . $conn->error;
}

// Закрываем соединение с базой данных
$conn->close();
header('Location: contacts.html'); // перенаправление
exit;
?>

