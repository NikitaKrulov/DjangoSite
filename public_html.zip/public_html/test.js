// let totalPrice = 0; // Переменная для хранения общей суммы
// let cart = ''; // Объявите переменную cart в глобальной области видимости
// let cartData = ''; // Объявите переменную cartData в глобальной области видимости

// fetch('getData.php')
//   .then(response => response.json()) // Используйте response.json() для обработки JSON
//   .then(data => {
//     if (data.message === 'empty') {
//       cart = 'empty';
//       console.log('cart is empty'); // Отладочное сообщение
//     } else {
//       cartData = data; 
//     }
//     updateCartDisplay(); // Вызов функции после получения данных
//   })
//   .catch(error => {
//     console.error('Произошла ошибка при получении данных:', error);
//   });
let totalPrice = 0;
let cart = '';
let cartData = '';

fetch('cart.php') // Используйте правильный путь к обработчику
  .then(response => response.json())
  .then(data => {
    if (data.length === 0) { // Проверка на пустую корзину
      cart = 'empty';
      console.log('cart is empty');
    } else {
      cartData = data; 
    }
    updateCartDisplay();
  })
  .catch(error => {
    console.error('Произошла ошибка при получении данных:', error);
  });


  // -----------------------------------

  function updateCartDisplay() {
    let itemContainer = document.querySelector('.item_container');

    if (cart === 'empty') {
        // Если корзина пуста, отображаем сообщение
        let notifContainer = document.createElement('div');
        notifContainer.classList.add('notif_container-Item');
    
        let imgElement = document.createElement('img');
        imgElement.src = '/media/empty_cart.png';
        imgElement.alt = 'Empty Cart Image';
        imgElement.classList.add('empty_cart_image'); 
        notifContainer.appendChild(imgElement);
    
        let notifText = document.createElement('div');
        notifText.classList.add('notif_text-Item');
        let notifParagraph = document.createElement('p');
        notifParagraph.textContent = "Здесь пока ничего нет :(, ";
    
        let notifLink = document.createElement('a');
        notifLink.href = "./index.html#product";
        notifLink.textContent = "добавьте товары";
    
        notifParagraph.appendChild(notifLink);
        notifText.appendChild(notifParagraph);
        notifContainer.appendChild(notifText);
    
        itemContainer.appendChild(notifContainer);
        const delBtns = document.getElementsByClassName('del_btn');
        for (let i = 0; i < delBtns.length; i++) {
            delBtns[i].style.display = 'none';
        }
    } else {
        // Если в корзине есть товары, отображаем их
        cartData.forEach(item => {
            let newItem = document.createElement('div');
            newItem.classList.add('item');

            newItem.innerHTML = `
                <img src="${item.image}" alt="product_img">
                <div class="item_text">
                    <p class="name_item">${item.name}</p>
                    <div class="count_btn_item">
                        <p>Количество: <span id="item-count">1</span></p>
                        <button id="decrement" class="btn_plus-minus">-</button>
                        <button id="increment" class="btn_plus-minus">+</button>
                    </div>
                </div>
                <div class="item_price">
                    <p class="price_item">${item.price}</p>
                </div>
            `;

            itemContainer.appendChild(newItem);
            totalPrice += parseFloat(item.price);
        });
        const delBtns = document.getElementsByClassName('del_btn');
        for (let i = 0; i < delBtns.length; i++) {
            delBtns[i].style.display = 'block';
        }
        updateItemCount()
    }
}


document.addEventListener("DOMContentLoaded", function () {
    const delBtns = document.getElementsByClassName('del_btn');
    const itemArray = document.getElementsByClassName('item');
    const delBtnArray = Array.from(delBtns);

    delBtnArray.forEach((delBtn) => {
        delBtn.addEventListener('click', function () {
            // Переводим NodeList в массив для использования forEach
            const items = Array.from(itemArray);

            // Добавляем класс DeL_IteM ко всем элементам item
            items.forEach(item => {
                item.classList.add('DeL_IteM');
            });

            // Запускаем таймер для удаления del_btn через 1 секунду
            setTimeout(() => {
                delBtn.remove();
            }, 1000);

            // Запускаем таймер для удаления элементов item через 3 секунды
            setTimeout(() => {
                items.forEach(item => {
                    item.remove();
                });
            
                // Создаем массив itemIds на основе данных в cartData
                const itemIds = cartData.map(item => item.ID);
            
                // Отправляем запрос к серверу для удаления данных из БД
                fetch('deleteData.php', {
                    method: 'POST',
                    body: JSON.stringify({ item_ids: itemIds }), // Параметр должен быть назван "item_ids" (или какой-то другой ключ, который вы хотите использовать)
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.message === 'success') {
                        console.log('Данные удалены из БД.');
                    } else {
                        console.error('Произошла ошибка при удалении данных из БД.');
                    }
                })
                .catch(error => {
                    console.error('Произошла ошибка при удалении данных:', error);
                });
            }, 3000);

            //  таймер для  уведомления через 4 секунды
            setTimeout(() => {
                const itemContainer = document.querySelector('.item_container');
                
                //  корзина пуста, отображаем сообщение
                let notifContainer = document.createElement('div');
                notifContainer.classList.add('notif_container-Item');
            
                let imgElement = document.createElement('img');
                imgElement.src = '/media/empty_cart.png';
                imgElement.alt = 'Empty Cart Image';
                imgElement.classList.add('empty_cart_image'); 
                notifContainer.appendChild(imgElement);
            
                let notifText = document.createElement('div');
                notifText.classList.add('notif_text-Item');
                let notifParagraph = document.createElement('p');
                notifParagraph.textContent = "Здесь пока ничего нет :(, ";
            
                let notifLink = document.createElement('a');
                notifLink.href = "./index.html#product";
                notifLink.textContent = "добавьте товары";
            
                notifParagraph.appendChild(notifLink);
                notifText.appendChild(notifParagraph);
                notifContainer.appendChild(notifText);
            
                itemContainer.appendChild(notifContainer);
                
            }, 3000);
            
        });
    });
});





document.addEventListener("DOMContentLoaded", function () {
    const countProdElement = document.getElementById('count_prod');
    const itemArray = document.getElementsByClassName('item');

    function updateItemCount() {
        const itemCount = itemArray.length;
        let totalItemCount = 0;
        let totalPrice = 0;

        for (const item of itemArray) {
            const itemCountElement = item.querySelector('#item-count');
            const priceElement = item.querySelector('.price_item');

            const count = parseInt(itemCountElement.textContent, 10);
            const price = parseFloat(priceElement.textContent.replace(/,/g, ''));

            totalItemCount += count;
            totalPrice += count * price;
        }

        countProdElement.textContent = totalItemCount;
        const resultPriceElement = document.querySelector('.result_price');
        const resultPrice2Element = document.querySelector('.result_price_2');
        resultPriceElement.textContent = `${totalPrice.toFixed(1)}`;
        resultPrice2Element.textContent = `${totalPrice.toFixed(1)}`;
        const priceInput = document.getElementById('price2');
        priceInput.value = `${totalPrice.toFixed(2)}`;
    }

    updateItemCount();
    setTimeout(updateItemCount, 3000);

    const itemContainer = document.querySelector('.item_container');

    itemContainer.addEventListener('click', function (event) {
        const itemCountElement = event.target.closest('.item').querySelector('#item-count');

        if (event.target.id === 'decrement') {
            let count = parseInt(itemCountElement.textContent, 10);
            if (count > 1) {
                count--;
                itemCountElement.textContent = count;
            }
        } else if (event.target.id === 'increment') {
            let count = parseInt(itemCountElement.textContent, 10);
            count++;
            itemCountElement.textContent = count;
        }

        updateItemCount();
    });
});

function placing_btn() {
    const placing = document.getElementById('placing');
    if (placing.style.display === 'none' || placing.style.display === '') {
      placing.style.display = 'flex';
      if(windowInnerHeight >= 700){}
      window.scrollTo(0, 0); 
    } else {
      placing.style.display = 'none';
    }
  };

