<?php
// $host = 'localhost';
// $dbname = 'nekitkrulo';
// $username = 'nekitkrulo';
// $password = 'FCWi5YN&1LHUW853';

// $mysqli = new mysqli($host, $username, $password, $dbname);

// if ($mysqli->connect_error) {
//     die("Ошибка подключения к базе данных: " . $mysqli->connect_error);
// }

// $sql = "SELECT * FROM DataToCart"; // Выберите все поля из таблицы "DataToCart"
// $result = $mysqli->query($sql);

// if ($result->num_rows > 0) {
//     $cartData = array();

//     while ($row = $result->fetch_assoc()) {
//         $cartData[] = $row;
//     }

//     echo json_encode($cartData); // Вернуть данные как JSON
// } else {
//     echo json_encode(array("message" => "empty"));
// }


// $mysqli->close();
?>
<?php
$host = 'localhost';
$dbname = 'nekitkrulo';
$username = 'nekitkrulo';
$password = 'FCWi5YN&1LHUW853';

$mysqli = new mysqli($host, $username, $password, $dbname);

if ($mysqli->connect_error) {
    die("Ошибка подключения к базе данных: " . $mysqli->connect_error);
}

// Получение данных из POST-запроса
$name = $_POST['name'];
$image = $_POST['image'];
$price = $_POST['price'];

// Подготовка SQL-запроса для вставки данных
$sqlInsert = "INSERT INTO DataToCart (image, name, price) VALUES (?, ?, ?)";
$sqlCheck = "SELECT * FROM DataToCart WHERE name = ?";

// Использование подготовленного запроса для предотвращения SQL-инъекций
$stmtInsert = $mysqli->prepare($sqlInsert);
$stmtCheck = $mysqli->prepare($sqlCheck);

$stmtCheck->bind_param("s", $name);
$stmtCheck->execute();

$resultCheck = $stmtCheck->get_result();

if ($resultCheck->num_rows > 0) {
    // Товар уже существует, ничего не делаем
    echo json_encode(array('message' => 'Товар уже в корзине!'));
} else {
    // Товара нет в корзине, добавляем
    $stmtInsert->bind_param("sss", $image, $name, $price);

    if ($stmtInsert->execute()) {
        echo json_encode(array('message' => 'Товар успешно добавлен в корзину!'));
    } else {
        echo json_encode(array('message' => 'Ошибка при добавлении данных: ' . $stmtInsert->error));
    }
}

// Закрытие соединения с базой данных
$stmtInsert->close();
$stmtCheck->close();
$mysqli->close();
?>
